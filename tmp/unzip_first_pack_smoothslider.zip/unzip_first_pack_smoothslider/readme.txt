XML/SWF Gallery PowerPlay Installation Instructions:
-------------------------------------------------

1. First install com_galleryxml.zip component through admin 

2. Then install mod_smoothslider.zip module thorugh admin

3. Publish "XML/SWF Smooth Slider" module to see the flash in frontend


If you have any installation problems or if you need help please open support ticket at http://support.xmlswf.com/

Visit our Forum at http://forum.xmlswf.com/ to discuss

Follow us on twitter at http://twitter.com/xmlswf to get updated about new releases or updates

Thanks for using XML/SWF product