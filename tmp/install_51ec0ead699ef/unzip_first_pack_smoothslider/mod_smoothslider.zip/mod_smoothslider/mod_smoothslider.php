<?php
/**
* @Copyright Copyright (C) 2010- xml/swf
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
/** ensure this file is being included by a parent file */
defined( '_JEXEC' ) or die( 'Restricted access' ); 

$bannerWidth                   = intval($params->get( 'bannerWidth', 750 ));
$bannerHeight                  = intval($params->get( 'bannerHeight', 399 ));
$backgroundColor         = trim($params->get( 'backgroundColor', '#FFFFFF' ));
$baseColor         = $params->get( 'baseColor', '0x000000' );
$wmode                 = trim($params->get( 'wmode', 'opaque' )); 
$catppv_id = '';

$MovieScale=trim($params->get( 'MovieScale'));

$ids    = trim($params->get( 'category_id', 0 ));

if (1 == trim($params->get( 'catppv_flag', '2' ))) {
	$catppv_id = str_replace (',', '_', $ids);
	$module_path = dirname(__FILE__).DS;
	if (!file_exists($module_path . 'mod_smoothslider'. $catppv_id . '.swf') ) {
		copy($module_path . 'mod_smoothslider.swf', $module_path . 'mod_smoothslider'. $catppv_id . '.swf');

		
///////// set chmod 0644 for creating .swf file  if server is not windows
	$os_string = php_uname('s');
	$cnt = substr_count($os_string, 'Windows');
	if($cnt =='0'){
		@chmod($module_path . 'mod_smoothslider'. $catppv_id . '.swf', 0644);
	}
	}
}

function create_defalultgcpn_newl($params)
{
$params_comg = &JComponentHelper::getParams('com_galleryxml');
$cat_images_path = $params_comg->get('cat_path', 'images/galleryxml/gallery');
$cat_images_path .= '/';
$database = & JFactory::getDBO();//new ps_DB();
$cat_ids                = trim($params->get( 'category_id', '0' ));
$add_query = '';
if ($cat_ids && $cat_ids != 0) {
	$ids  = explode(",", $cat_ids);
	if (is_array($ids)) {
		foreach ($ids as $curr_id) {
			$add_query_arr[] = " id = " . $curr_id . " ";
		}
		$add_query = " AND " . implode("OR", $add_query_arr);
	}
}

$query = "Select * FROM #__galleryxmlc  WHERE publish = 1 " . $add_query . " ORDER BY ordnum ";
$database->setQuery($query);
$cat_q_res = $database->loadObjectList();

$xml_category_tags = '<?xml version="1.0" encoding="UTF-8"?>
<slideshow >
	<baseDef 
	transitionTime="'.trim($params->get( 'transitionTime', '3' )).'"
	autoScale="'.trim($params->get( 'autoScale', '1' )).'"
	autoAlign="'.trim($params->get( 'autoAlign', '1' )).'"
	autoSlideTime="'.trim($params->get( 'autoSlideTime', '5' )).'"
	menuspeed = "'.trim($params->get( 'menuspeed', '10' )).'"
	menuXpos="'.trim($params->get( 'menuXpos', '100' )).'"
	menuWidth="'.trim($params->get( 'menuWidth', '200' )).'"
	menuFontSize="'.trim($params->get( 'menuFontSize', '12' )).'"
	borderColor="'.trim($params->get( 'borderColor', '0xb0cb5b' )).'"
	menuColor="'.trim($params->get( 'menuColor', '0xffffff' )).'"
	menuButtonColor="'.trim($params->get( 'menuButtonColor', '0xe2ead7' )).'"
	menuButtonOverColor="'.trim($params->get( 'menuButtonOverColor', '0x558204' )).'"
	menualpha="'.trim($params->get( 'menualpha', '50' )).'"
	menuTextColor= "'.trim($params->get( 'menuTextColor', '0x3f6500' )).'"
	menuOverTextColor="'.trim($params->get( 'menuOverTextColor', '0xffffff' )).'"
	boxwidth="'.trim($params->get( 'boxwidth', '225' )).'"
	boxheight="'.trim($params->get( 'boxheight', '150' )).'"
	infoFontSizeBig="'.trim($params->get( 'infoFontSizeBig', '16' )).'"
	infoFontSizeSmall="'.trim($params->get( 'infoFontSizeSmall', '10' )).'"
	numberingColor="'.trim($params->get( 'numberingColor', '0xffffff' )).'"
	numberingColor1="'.trim($params->get( 'numberingColor1', '0xffffff' )).'"
	numberingColorOver="'.trim($params->get( 'numberingColorOver', '0xff0000' )).'"
	tagColor="'.trim($params->get( 'tagColor', '0x5a889f' )).'"
	tagXpos="'.trim($params->get( 'tagXpos', '650' )).'"
	tagTextColor="'.trim($params->get( 'tagTextColor', '0xffffff' )).'"
	tagTextSize="'.trim($params->get( 'tagTextSize', '20' )).'"
	/>
';
foreach ($cat_q_res as $curr_category) 
{

$ret_arr = Images_gcpnnewl($curr_category->id, $params, $curr_category->linkit);
	if ($ret_arr['flag']) {
		$xml_category_tags .= '
	<cat title="'.$curr_category->name.'">';
		$xml_category_tags .= $ret_arr['xml'];
		$xml_category_tags .= '
	</cat>';
	}
}

$xml_category_tags .= '
</slideshow>';

return $xml_category_tags;
}


function Images_gcpnnewl($cat_id, $params, $curr_link)
{
$params_comg = &JComponentHelper::getParams('com_galleryxml');
$images_path = $params_comg->get('pic_path', 'images/galleryxml/gallery');
$images_path .= '/';
$ret_arr = array ('flag'=>false, 'xml'=>'');
$query = "Select * FROM #__galleryxml WHERE catid = " . $cat_id . " AND publish = 1 ORDER BY ordnum";
	$db = & JFactory::getDBO();
	$db->setQuery($query);
	$prod_q_res = $db->loadObjectList();
$xml_image_tags = "";

	foreach ($prod_q_res as $curr_product) 
{
	$ret_arr['flag'] = true;

	if ($params->get( 'showdesc', '1' ) == 1) {
		$product_dsc = $curr_product->descr;
	} else {
		$product_dsc = '';
	}
	$tag = $params->get( 'notetext', 'Come with us' );
	$product_name = $curr_product->name;
	
	$xml_image_tags .= '
		<pic url="'.$curr_product->linkname.'" target="'.trim($params->get( 'target', '_blank' )).'" x1="'.trim($params->get( 'x1', '0' )).'" x2="'.trim($params->get( 'x2', '0' )).'" FindMoreName = "'.trim($params->get( 'FindMoreName', 'View More' )).'"
		FindMoreText = "" FindMoreSText=""
		FindMoreColorBack="'.trim($params->get( 'FindMoreColorBack', '0x095373' )).'" FindMoreColorText="'.trim($params->get( 'FindMoreColorText', '0xffffff' )).'" FindMoreAlpha="'.trim($params->get( 'FindMoreAlpha', '0.3' )).'" FindMoreButtonColor="'.trim($params->get( 'FindMoreButtonColor', '0x38c0fb' )).'" FindMoreButtonTextColor ="'.trim($params->get( 'FindMoreButtonTextColor', '0xffffff' )).'" pic="' .JURI::root().$images_path.$curr_product->image. '"   tag="'.$tag.'"><moreText><![CDATA['.$product_name.']]></moreText> <MoreSText><![CDATA['.$product_dsc.']]></MoreSText> </pic>';
}
$ret_arr['xml'] = $xml_image_tags;
return $ret_arr;
}

$xml_data = create_defalultgcpn_newl($params);
$module_path = dirname(__FILE__).DS;
$xmlslides_filename = $module_path.'default'.$catppv_id.'.xml';
$xmlslides_file = fopen($xmlslides_filename,'w');
fwrite($xmlslides_file, $xml_data);

///////// set chmod 0777 for creating .xml file  if server is not windows
	$os_string = php_uname('s');
	$cnt = substr_count($os_string, 'Windows');
	if($cnt =='0'){
		@chmod($xmlslides_filename, 0777);
	}

fclose($xmlslides_file);
?>

<div align="center">
<script language="javascript">AC_FL_RunContent = 0;</script>
<script src="<?php echo JURI::root()?>modules/mod_smoothslider/AC_RunActiveContent.js" language="javascript"></script>
<script language="javascript">
	if (AC_FL_RunContent == 0) {
		alert("This page requires AC_RunActiveContent.js.");
	} else {
		AC_FL_RunContent(
			'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0',
			'width', '<?php echo $bannerWidth;?>',
			'height', '<?php echo $bannerHeight; ?>',
			'src', '<?php echo JURI::root()?>modules/mod_smoothslider/mod_smoothslider<?php echo $catppv_id; ?>',
			'quality', 'high',
			'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
			'align', 'middle',
			'play', 'true',
			'loop', 'true',
			'scale', 'showall',
			'wmode', '<?php echo $wmode;?>',
			'devicefont', 'false',
			'id', 'flcontent',
			'bgcolor', '<?php echo $backgroundColor; ?>',
			'name', 'flcontent',
			'menu', 'true',
			'allowFullScreen', 'true',
			'allowScriptAccess','sameDomain',
			'movie', '<?php echo JURI::root()?>modules/mod_smoothslider/mod_smoothslider<?php echo $catppv_id; ?>',
			'salign', '',
			'FlashVars','xmlfileurl=<?php echo JURI::root()?>modules/mod_smoothslider/default<?php echo $catppv_id; ?>.xml&baseColor=<?php echo $baseColor; ?>'
			); //end AC code
	}
</script>

<noscript>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="<?php echo $bannerWidth;?>" height="<?php echo $bannerHeight; ?>" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="wmode" value="<?php echo $wmode;?>" />
<param name="FlashVars" value="xmlfileurl=<?php echo JURI::root()?>modules/mod_smoothslider/default<?php echo $catppv_id; ?>.xml&baseColor=<?php echo $baseColor; ?>"/>
<param name="allowFullScreen" value="true" />	<param name="movie" value="<?php echo JURI::root().'modules/mod_smoothslider/mod_smoothslider'.$catppv_id.'.swf';?>" /><param name="quality" value="high" /><param name="bgcolor" value="<?php echo $backgroundColor; ?>" />
<embed src="<?php echo JURI::root().'modules/mod_smoothslider/mod_smoothslider'.$catppv_id.'.swf';?>" FlashVars="xmlfileurl=<?php echo JURI::root()?>modules/mod_smoothslider/default<?php echo $catppv_id; ?>.xml&baseColor=<?php echo $baseColor; ?>" quality="high" wmode="<?php echo $wmode;?>"
 bgcolor="<?php echo $backgroundColor;?>" width="<?php echo $bannerWidth;?>" height="<?php echo $bannerHeight; ?>" name="preview" align="middle" allowScriptAccess="sameDomain" allowFullScreen="true" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>
</noscript>
</div>