<?php
/**
* @Copyright Copyright (C) 2010- xml/swf
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/ 
// No direct access
 
defined('_JEXEC') or die('Restricted access'); 

echo "<div style='text-align:center'><h1 style='color:#ff0000'>This component is only for admin purpose like adding categories and images. You must publish the module to see the images in flash. Please watch the below demo video on how to install and enable module. If you want to remove this message please edit: 'components/com_galleryxml/views/gallery/tmpl/default.php'</h1><br /> <iframe title='YouTube video player' width='480' height='390' src='http://www.youtube.com/embed/myPIs9tjRpM' frameborder='0' allowfullscreen></iframe>";
?>