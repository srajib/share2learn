<?php
/**
* @Copyright Copyright (C) 2010- xml/swf
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
// no direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
/**
 * HTML View class for the Gallery XML Component
 *
 * @package    Gallery XML
 */
 
class GalleryViewGallery extends JView
{
    function display($tpl = null)
    {
        parent::display($tpl);
    }
}