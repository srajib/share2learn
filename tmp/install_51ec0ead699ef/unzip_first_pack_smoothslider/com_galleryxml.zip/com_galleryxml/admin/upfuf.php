<?php
/**
* @Copyright Copyright (C) 2010- xml/swf
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
function CreateThumbF($bigi_name, $thumb_name, $ext, $t_x, $t_y)
{
	$jpg_imgr = false;
	switch ($ext) {
		case 'jpg':
		case 'jpeg':
			if (function_exists('imagecreatefromjpeg')) {
				$jpg_imgr = imagecreatefromjpeg($bigi_name . '.' . $ext);
			}
		break;
		case 'png':
			if (function_exists('imagecreatefrompng')) {
				$jpg_imgr = imagecreatefrompng($bigi_name . '.' . $ext);
			}
		break;
		case 'bmp':
			if (function_exists('imagecreatefromwbmp')) {
				$jpg_imgr = imagecreatefromwbmp($bigi_name . '.' . $ext);
			}
		break;
		case 'gif':
			if (function_exists('imagecreatefromgif')) {
				$jpg_imgr = imagecreatefromgif($bigi_name . '.' . $ext);
			}
		break;
		default:
			return false;
	}
	
	if ($jpg_imgr) {
		$big_x = imagesx($jpg_imgr);
		$big_y = imagesy($jpg_imgr);
		
		$ratio_orig = $big_x/$big_y;
		if ($t_x/$t_y > $ratio_orig) {
		   $t_x = $t_y * $ratio_orig;
		} else {
		   $t_y = $t_x/$ratio_orig;
		}

		$dst_img=ImageCreateTrueColor($t_x, $t_y);
		imagecopyresampled($dst_img, $jpg_imgr,0,0,0,0,$t_x,$t_y,$big_x,$big_y); 
		imagejpeg($dst_img, $thumb_name . '.' . $ext, 100);
	} else {
		copy($bigi_name . '.' . $ext, $thumb_name . '.' . $ext);
	}
}

	$dirnamec = dirname(__FILE__);
	if (strstr($dirnamec, '/')) {
		$DS = '/';
	} else {
		$DS = '\\';
	}
	
	$dir_arr = explode($DS, $dirnamec);
	$dir_arr = array_slice($dir_arr, 0, -3);
	
	$root_dirn = implode($DS, $dir_arr) . $DS;
	
	$dirnamec .= $DS;
	

require_once('../../../configuration.php');
$configs = new JConfig();

$q_cparams = "Select `params` FROM `". $configs->dbprefix ."components` WHERE `link` = 'option=com_galleryxml' ";

$db_link = mysql_connect($configs->host, $configs->user, $configs->password);

$thumb_x = '70';
$thumb_y = '50';
$pic_path = "images/galleryxml/gallery";
if ($db_link) {
  if (mysql_select_db($configs->db, $db_link)) {
	$qcp_res = mysql_query($q_cparams);
	if ($qcp_res) {
	  if (mysql_num_rows($qcp_res) > 0) {
		$row = mysql_fetch_assoc($qcp_res);
		if ($row['params'] && trim($row['params']) != '') {
			$ccpar_new = strtok($row['params'], "=\n");
			$ccpar = trim($ccpar_new);
			while ($ccpar_new !== false) {
				$ccpar_new = strtok("=\n");
				if ($ccpar == "pic_path") {
					$pic_path = trim($ccpar_new);
				} elseif ($ccpar == "thumb_x") {
					$thumb_x = trim($ccpar_new);
				} elseif ($ccpar == "thumb_y") {
					$thumb_y = trim($ccpar_new);
				} elseif ($ccpar == "secur_w") {
					$secur_w = trim($ccpar_new);
				}
				$ccpar = trim($ccpar_new);
			}
		}
	  }
	}
  } else {
	exit();
  }    
} else {
	exit();
}
if (!isset($_POST['decret']) || $_POST['decret'] != $secur_w) {
	exit();
}

$gallery_path = $root_dirn . $pic_path . $DS;

if ($_FILES["Filedata"]["error"] > 0 || !(strtolower(substr($_FILES["Filedata"]["name"], -5)) == ".jpeg" || strtolower(substr($_FILES["Filedata"]["name"], -4)) == ".jpg" || strtolower(substr($_FILES["Filedata"]["name"], -4)) == ".gif"  || strtolower(substr($_FILES["Filedata"]["name"], -4)) == ".bmp" || strtolower(substr($_FILES["Filedata"]["name"], -4)) == ".png")) {
	exit();
} else {
	$img_ext = strtolower(strrchr($_FILES["Filedata"]["name"], '.'));
	$pic_name = substr($_FILES["Filedata"]["name"], 0, -strlen($img_ext));
	$image_name_end = preg_replace('/[^a-zA-Z0-9_]/', '_', $pic_name) . $img_ext;
	$image_name = $image_name_end;
	$noex_f_index = 0;
	while(file_exists($gallery_path . $image_name_end)) {
		$noex_f_index++;
		$image_ext = strrchr($image_name, '.');
		$image_name_end = substr($image_name, 0, -strlen($image_ext)) . '_' . $noex_f_index . $image_ext;				
	}
	if ($image_name_end != $image_name) {
		$image_name = $image_name_end;
	}
	move_uploaded_file($_FILES["Filedata"]["tmp_name"], $gallery_path . $image_name);
}

$thumb_name = 'noimage_thumb.jpg';
if (file_exists($gallery_path . $image_name)) {
	$thumb_name_end = 'thumb_' . $image_name;
	$thumb_name = $thumb_name_end;
	$noex_f_index = 0;
	while(file_exists($gallery_path . $thumb_name_end)) {
		$noex_f_index++;
		$thumb_ext = strrchr($thumb_name, '.');
		$thumb_name_end = substr($thumb_name, 0, -strlen($thumb_ext)) . '_' . $noex_f_index . $thumb_ext;				
	}
	if ($thumb_name_end != $thumb_name) {
		$thumb_name = $thumb_name_end;
	}
	$thumb_ext = substr(strrchr($thumb_name, '.'), 1);
	$cnt_ext_chr = -(strlen($thumb_ext) + 1);
	$thumb_noext = $gallery_path . substr($thumb_name, 0, $cnt_ext_chr);
	$image_noext = $gallery_path . substr($image_name, 0, $cnt_ext_chr);
	CreateThumbF($image_noext, $thumb_noext, $thumb_ext, $thumb_x, $thumb_y);
}



$ord_numb = 1;
if (is_numeric($_POST['catid'])) {
	$cat_id = $_POST['catid'];
} else {
	$cat_id = 1;
}
$q_maxord = ' SELECT MAX(ordnum) as maxordnum FROM '. $configs->dbprefix .'galleryxml WHERE catid = ' . $cat_id;
$qmo_res = mysql_query($q_maxord);
if ($qmo_res) {
  if (mysql_num_rows($qmo_res) > 0) {
	$row = mysql_fetch_assoc($qmo_res);
	if(is_numeric($row['maxordnum'])) {
		$ord_numb = $row['maxordnum'] + 1;
	}
  }
}

$insert_q = "INSERT INTO ". $configs->dbprefix ."galleryxml  VALUES (NULL,".$cat_id.",".$ord_numb.",1,'".$pic_name."','".$pic_name."','".'thumb_'.$pic_name."','".$pic_name."','" .$thumb_name. "','".$image_name."','','',1)";
mysql_query($insert_q);

mysql_close($db_link);
?>