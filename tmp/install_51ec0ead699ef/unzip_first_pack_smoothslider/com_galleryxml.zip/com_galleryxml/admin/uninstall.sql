DROP TABLE IF EXISTS `#__galleryxml`;
DROP TABLE IF EXISTS `#__galleryxmlc`;